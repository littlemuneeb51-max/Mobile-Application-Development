# Gemini Chatbot - Full Project Code

This document contains the complete source code for the Gemini Chatbot application.

## 1. package.json
```json
{
  "name": "react-example",
  "private": true,
  "version": "0.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite --port=3000 --host=0.0.0.0",
    "build": "vite build",
    "preview": "vite preview",
    "clean": "rm -rf dist",
    "lint": "tsc --noEmit"
  },
  "dependencies": {
    "@google/genai": "^1.29.0",
    "@tailwindcss/vite": "^4.1.14",
    "@vitejs/plugin-react": "^5.0.4",
    "dotenv": "^17.2.3",
    "express": "^4.21.2",
    "lucide-react": "^0.546.0",
    "motion": "^12.23.24",
    "react": "^19.0.0",
    "react-dom": "^19.0.0",
    "react-markdown": "^10.1.0",
    "vite": "^6.2.0"
  },
  "devDependencies": {
    "@types/express": "^4.17.21",
    "@types/node": "^22.14.0",
    "autoprefixer": "^10.4.21",
    "tailwindcss": "^4.1.14",
    "tsx": "^4.21.0",
    "typescript": "~5.8.2",
    "vite": "^6.2.0"
  }
}
```

## 2. metadata.json
```json
{
  "name": "Gemini Chatbot",
  "description": "A responsive AI chatbot powered by Google Gemini, featuring Material 3 design and real-time messaging.",
  "requestFramePermissions": []
}
```

## 3. vite.config.ts
```typescript
import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig, loadEnv} from 'vite';

export default defineConfig(({mode}) => {
  const env = loadEnv(mode, '.', '');
  return {
    plugins: [react(), tailwindcss()],
    define: {
      'process.env.GEMINI_API_KEY': JSON.stringify(env.GEMINI_API_KEY),
    },
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
    },
  };
});
```

## 4. index.html
```html
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>My Google AI Studio App</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
```

## 5. src/main.tsx
```typescript
import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
```

## 6. src/index.css
```css
@import "tailwindcss";

@theme {
  --font-sans: "Inter", ui-sans-serif, system-ui, sans-serif;
  --font-mono: "JetBrains Mono", ui-monospace, SFMono-Regular, monospace;
}

@layer base {
  :root {
    --bg-primary: #f8f9fa;
    --bg-secondary: #ffffff;
    --bg-sidebar: #f0f4f9;
    --text-primary: #1c1b1f;
    --text-secondary: #444746;
    --border-color: #e1e2ec;
    --accent-color: #0b57d0;
    --accent-hover: #0842a0;
  }

  .dark {
    --bg-primary: #131314;
    --bg-secondary: #1e1f20;
    --bg-sidebar: #1e1f20;
    --text-primary: #e3e3e3;
    --text-secondary: #c4c7c5;
    --border-color: #444746;
    --accent-color: #a8c7fa;
    --accent-hover: #d3e3fd;
  }

  body {
    @apply bg-[var(--bg-primary)] text-[var(--bg-primary)] transition-colors duration-300;
  }
}

/* Custom Scrollbar */
::-webkit-scrollbar {
  width: 8px;
}

::-webkit-scrollbar-track {
  @apply bg-transparent;
}

::-webkit-scrollbar-thumb {
  @apply bg-[#e1e2ec] dark:bg-[#444746] rounded-full hover:bg-[#c4c7c5] dark:hover:bg-[#5f6368] transition-colors;
}

/* Markdown Styles */
.prose {
  @apply max-w-none text-[var(--text-primary)];
}

.prose pre {
  @apply bg-[#f0f4f9] dark:bg-[#131314] rounded-xl p-4 overflow-x-auto border border-[var(--border-color)] relative;
}

.prose code {
  @apply font-mono text-sm text-[#0b57d0] dark:text-[#a8c7fa] bg-[#0b57d0]/5 dark:bg-[#a8c7fa]/10 px-1.5 py-0.5 rounded-md;
}

.prose pre code {
  @apply bg-transparent p-0 text-[var(--text-primary)] dark:text-[var(--text-primary)];
}

.prose h1, .prose h2, .prose h3, .prose h4 {
  @apply text-[var(--text-primary)] font-bold mt-6 mb-4;
}

.prose p {
  @apply mb-4 leading-relaxed;
}

.prose ul, .prose ol {
  @apply mb-4 pl-6;
}

.prose li {
  @apply mb-2;
}

.prose blockquote {
  @apply border-l-4 border-[var(--accent-color)] pl-4 italic text-[var(--text-secondary)] my-4;
}
```

## 7. src/App.tsx
```typescript
import { useState, useRef, useEffect, useCallback } from 'react';
import { GoogleGenAI } from "@google/genai";
import { 
  Send, 
  User, 
  Bot, 
  Loader2, 
  AlertCircle, 
  Trash2, 
  Copy, 
  Check, 
  Sparkles, 
  ThumbsUp, 
  ThumbsDown, 
  Plus, 
  Menu, 
  X, 
  MessageSquare, 
  ChevronLeft, 
  ChevronRight, 
  Settings,
  Moon,
  Sun,
  Search,
  History,
  Download,
  Share2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';

interface Message {
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
  feedback?: 'up' | 'down';
}

interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  lastModified: Date;
}

export default function App() {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [input, setInput] = useState('');
  const MAX_CHARS = 4000;
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isInitialized, setIsInitialized] = useState(false);
  const [copiedId, setCopiedId] = useState<number | null>(null);
  const [isDarkMode, setIsDarkMode] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('gemini_dark_mode') === 'true' || 
             window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [systemPrompt, setSystemPrompt] = useState("You are a helpful, professional, and friendly AI assistant powered by Gemini. Provide clear, accurate, and engaging responses.");
  
  const scrollRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const currentSession = sessions.find(s => s.id === currentSessionId) || null;
  const messages = currentSession?.messages || [];
  const chatTitle = currentSession?.title || 'New Chat';

  // Dark mode effect
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('gemini_dark_mode', isDarkMode.toString());
  }, [isDarkMode]);

  const setMessages = useCallback((newMessages: Message[] | ((prev: Message[]) => Message[])) => {
    setSessions(prev => prev.map(s => {
      if (s.id === currentSessionId) {
        const updatedMessages = typeof newMessages === 'function' ? newMessages(s.messages) : newMessages;
        return { ...s, messages: updatedMessages, lastModified: new Date() };
      }
      return s;
    }));
  }, [currentSessionId]);

  const setChatTitle = useCallback((newTitle: string) => {
    setSessions(prev => prev.map(s => {
      if (s.id === currentSessionId) {
        return { ...s, title: newTitle, lastModified: new Date() };
      }
      return s;
    }));
  }, [currentSessionId]);

  // Load history on mount
  useEffect(() => {
    const savedSessions = localStorage.getItem('gemini_chat_sessions');
    const savedCurrentId = localStorage.getItem('gemini_current_session_id');
    
    if (savedSessions) {
      try {
        const parsed = JSON.parse(savedSessions);
        const hydrated = parsed.map((s: any) => ({
          ...s,
          lastModified: new Date(s.lastModified),
          messages: s.messages.map((m: any) => ({
            ...m,
            timestamp: new Date(m.timestamp)
          }))
        }));
        setSessions(hydrated);
        if (savedCurrentId && hydrated.some((s: any) => s.id === savedCurrentId)) {
          setCurrentSessionId(savedCurrentId);
        } else if (hydrated.length > 0) {
          setCurrentSessionId(hydrated[0].id);
        }
      } catch (e) {
        console.error("Failed to parse chat history", e);
      }
    } else {
      // Create initial session
      const initialId = crypto.randomUUID();
      const initialSession: ChatSession = {
        id: initialId,
        title: 'New Chat',
        messages: [],
        lastModified: new Date(),
      };
      setSessions([initialSession]);
      setCurrentSessionId(initialId);
    }
    setIsInitialized(true);
  }, []);

  // Save history whenever sessions or current ID change
  useEffect(() => {
    if (isInitialized) {
      localStorage.setItem('gemini_chat_sessions', JSON.stringify(sessions));
      if (currentSessionId) {
        localStorage.setItem('gemini_current_session_id', currentSessionId);
      }
    }
  }, [sessions, currentSessionId, isInitialized]);

  const createNewSession = useCallback(() => {
    const newId = crypto.randomUUID();
    const newSession: ChatSession = {
      id: newId,
      title: 'New Chat',
      messages: [],
      lastModified: new Date(),
    };
    setSessions(prev => [newSession, ...prev]);
    setCurrentSessionId(newId);
    setIsMobileMenuOpen(false);
  }, []);

  const deleteSession = useCallback((id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSessions(prev => {
      const filtered = prev.filter(s => s.id !== id);
      if (filtered.length === 0) {
        const newId = crypto.randomUUID();
        const initialSession: ChatSession = {
          id: newId,
          title: 'New Chat',
          messages: [],
          lastModified: new Date(),
        };
        setCurrentSessionId(newId);
        return [initialSession];
      }
      if (currentSessionId === id) {
        setCurrentSessionId(filtered[0].id);
      }
      return filtered;
    });
  }, [currentSessionId]);

  const clearHistory = useCallback(() => {
    if (currentSessionId) {
      setMessages([]);
      setChatTitle('New Chat');
    }
  }, [currentSessionId, setMessages, setChatTitle]);

  const copyToClipboard = useCallback((text: string, id: number) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    });
  }, []);

  const handleFeedback = useCallback((idx: number, type: 'up' | 'down') => {
    setMessages(prev => prev.map((msg, i) => 
      i === idx ? { ...msg, feedback: msg.feedback === type ? undefined : type } : msg
    ));
  }, []);

  // Scroll to bottom whenever messages change
  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading, scrollToBottom]);

  const SidebarContent = () => {
    const filteredSessions = sessions.filter(s => 
      s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.messages.some(m => m.text.toLowerCase().includes(searchQuery.toLowerCase()))
    );

    return (
      <div className="flex flex-col h-full bg-[#f0f4f9] dark:bg-[#1e1f20] text-[#1c1b1f] dark:text-[#e3e3e3] transition-colors duration-300">
        <div className="p-4 space-y-4">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={createNewSession}
            className="w-full flex items-center gap-3 px-4 py-3 bg-[#c2e7ff] dark:bg-[#004a77] text-[#001d35] dark:text-[#c2e7ff] rounded-2xl hover:bg-[#b3d9f2] dark:hover:bg-[#005a8f] transition-all font-semibold text-sm shadow-sm"
          >
            <Plus size={20} />
            <span>New Chat</span>
          </motion.button>

          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#444746] dark:text-[#c4c7c5]" />
            <input
              type="text"
              placeholder="Search chats..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white dark:bg-[#131314] border border-[#e1e2ec] dark:border-[#444746] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0b57d0] dark:focus:ring-[#a8c7fa] transition-all"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-2 py-2 space-y-1">
          {filteredSessions.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-10 text-[#444746] dark:text-[#c4c7c5] opacity-60">
              <History size={32} strokeWidth={1.5} />
              <p className="text-xs mt-2 font-medium">No chats found</p>
            </div>
          ) : (
            filteredSessions.map((session) => (
              <div
                key={session.id}
                onClick={() => {
                  setCurrentSessionId(session.id);
                  setIsMobileMenuOpen(false);
                }}
                className={`group flex items-center justify-between p-3 rounded-xl cursor-pointer transition-all ${
                  currentSessionId === session.id
                    ? 'bg-[#d3e3fd] dark:bg-[#004a77]/40 text-[#041e49] dark:text-[#c2e7ff] font-semibold'
                    : 'hover:bg-[#e1e5ea] dark:hover:bg-[#333537] text-[#444746] dark:text-[#c4c7c5]'
                }`}
              >
                <div className="flex items-center gap-3 overflow-hidden">
                  <MessageSquare size={18} className="shrink-0 opacity-70" />
                  <span className="truncate text-sm">{session.title}</span>
                </div>
                <button
                  onClick={(e) => deleteSession(session.id, e)}
                  className="opacity-0 group-hover:opacity-100 p-1.5 hover:bg-red-100 dark:hover:bg-red-900/30 hover:text-red-600 dark:hover:text-red-400 rounded-lg transition-all"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            ))
          )}
        </div>

        <div className="p-4 border-t border-[#e1e2ec] dark:border-[#444746]">
          <button 
            onClick={() => setIsSettingsOpen(true)}
            className="w-full flex items-center gap-3 px-4 py-3 text-[#444746] dark:text-[#c4c7c5] hover:bg-[#e1e5ea] dark:hover:bg-[#333537] rounded-xl transition-all text-sm font-medium"
          >
            <Settings size={18} />
            <span>Settings</span>
          </button>
        </div>
      </div>
    );
  };

  const handleSend = async () => {
    if (!input.trim() || isLoading || input.length > MAX_CHARS) return;

    const userMessage: Message = {
      role: 'user',
      text: input.trim(),
      timestamp: new Date(),
    };

    const currentInput = input;
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    
    // Reset textarea height
    const textarea = document.querySelector('textarea');
    if (textarea) {
      textarea.style.height = 'auto';
    }

    setIsLoading(true);
    setError(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });
      const model = "gemini-3-flash-preview";
      
      // Filter history to ensure it starts with a 'user' message and alternates roles
      // Gemini API requires the first message in 'contents' to be from the 'user'
      const history = messages.map(m => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));

      const apiContents = history[0]?.role === 'model' ? history.slice(1) : history;
      apiContents.push({
        role: 'user',
        parts: [{ text: userMessage.text }]
      });

      const response = await ai.models.generateContent({
        model: model,
        contents: apiContents,
        config: {
          systemInstruction: systemPrompt,
        }
      });

      const aiText = response.text || "I'm sorry, I couldn't generate a response.";
      
      setMessages((prev) => [
        ...prev,
        {
          role: 'model',
          text: aiText,
          timestamp: new Date(),
        },
      ]);
    } catch (err: any) {
      console.error("Gemini API Error:", err);
      
      let userFriendlyError = "An unexpected error occurred. Please try again.";
      const errorMessage = err.message?.toLowerCase() || "";
      
      if (errorMessage.includes("fetch") || errorMessage.includes("network")) {
        userFriendlyError = "Network error: Please check your internet connection and try again.";
      } else if (errorMessage.includes("api_key") || errorMessage.includes("key not valid")) {
        userFriendlyError = "Configuration error: The API key is invalid or missing. Please contact support.";
      } else if (errorMessage.includes("quota") || errorMessage.includes("429")) {
        userFriendlyError = "Rate limit exceeded: You've sent too many messages. Please wait a moment before trying again.";
      } else if (errorMessage.includes("safety") || errorMessage.includes("blocked")) {
        userFriendlyError = "Content blocked: The request was flagged by safety filters. Please try rephrasing your message.";
      } else if (errorMessage.includes("500") || errorMessage.includes("internal")) {
        userFriendlyError = "Server error: Gemini is experiencing internal issues. Please try again in a few minutes.";
      } else if (errorMessage.includes("400")) {
        userFriendlyError = "Request error: There was an issue with the message format. Please try a different query.";
      }

      setInput(currentInput);
      setError(userFriendlyError);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex h-screen bg-[#f8f9fa] dark:bg-[#131314] font-sans text-[#1c1b1f] dark:text-[#e3e3e3] relative overflow-hidden transition-colors duration-300">
      {/* Settings Modal */}
      <AnimatePresence>
        {isSettingsOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSettingsOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-lg bg-white dark:bg-[#1e1f20] rounded-3xl shadow-2xl overflow-hidden border border-[#e1e2ec] dark:border-[#444746]"
            >
              <div className="p-6 border-b border-[#e1e2ec] dark:border-[#444746] flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-[#0b57d0]/10 dark:bg-[#a8c7fa]/10 rounded-xl text-[#0b57d0] dark:text-[#a8c7fa]">
                    <Settings size={20} />
                  </div>
                  <h2 className="text-xl font-bold">Settings</h2>
                </div>
                <button 
                  onClick={() => setIsSettingsOpen(false)}
                  className="p-2 hover:bg-[#f0f4f9] dark:hover:bg-[#333537] rounded-full transition-all"
                >
                  <X size={20} />
                </button>
              </div>
              <div className="p-6 space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold uppercase tracking-widest text-[#444746] dark:text-[#c4c7c5] opacity-60">System Instruction</label>
                  <textarea
                    value={systemPrompt}
                    onChange={(e) => setSystemPrompt(e.target.value)}
                    className="w-full h-32 p-4 bg-[#f0f4f9] dark:bg-[#131314] border border-[#e1e2ec] dark:border-[#444746] rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0b57d0] dark:focus:ring-[#a8c7fa] resize-none transition-all"
                    placeholder="Tell Gemini how to behave..."
                  />
                  <p className="text-[11px] text-[#444746] dark:text-[#c4c7c5] opacity-60 italic">This prompt guides Gemini's personality and response style for all chats.</p>
                </div>
                
                <div className="flex items-center justify-between p-4 bg-[#f0f4f9] dark:bg-[#131314] rounded-2xl border border-[#e1e2ec] dark:border-[#444746]">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-white dark:bg-[#1e1f20] rounded-lg shadow-sm">
                      {isDarkMode ? <Moon size={18} className="text-[#a8c7fa]" /> : <Sun size={18} className="text-[#0b57d0]" />}
                    </div>
                    <div>
                      <p className="text-sm font-bold">Dark Mode</p>
                      <p className="text-xs text-[#444746] dark:text-[#c4c7c5]">Switch theme appearance</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setIsDarkMode(!isDarkMode)}
                    className={`relative w-12 h-6 rounded-full transition-colors duration-300 focus:outline-none ${
                      isDarkMode ? 'bg-[#0b57d0]' : 'bg-[#c4c7c5]'
                    }`}
                  >
                    <motion.div
                      animate={{ x: isDarkMode ? 26 : 2 }}
                      className="absolute top-1 left-0 w-4 h-4 bg-white rounded-full shadow-sm"
                    />
                  </button>
                </div>
              </div>
              <div className="p-6 bg-[#f0f4f9] dark:bg-[#131314] border-t border-[#e1e2ec] dark:border-[#444746] flex justify-end">
                <button
                  onClick={() => setIsSettingsOpen(false)}
                  className="px-6 py-2 bg-[#0b57d0] dark:bg-[#a8c7fa] text-white dark:text-[#001d35] rounded-xl font-bold text-sm hover:opacity-90 transition-all shadow-lg shadow-blue-200/50 dark:shadow-none"
                >
                  Done
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileMenuOpen(false)}
              className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40 lg:hidden"
            />
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed inset-y-0 left-0 w-[280px] z-50 lg:hidden"
            >
              <SidebarContent />
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Desktop Sidebar */}
      <motion.aside
        initial={false}
        animate={{ width: isSidebarOpen ? 300 : 0, opacity: isSidebarOpen ? 1 : 0 }}
        className="hidden lg:block border-r border-[#e1e2ec] dark:border-[#444746] overflow-hidden bg-[#f0f4f9] dark:bg-[#1e1f20] transition-colors duration-300"
      >
        <div className="w-[300px] h-full">
          <SidebarContent />
        </div>
      </motion.aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 relative">
        {/* Dynamic Background Elements */}
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-[#0b57d0]/5 dark:bg-[#a8c7fa]/5 rounded-full blur-[120px] pointer-events-none animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-[#a8c7fa]/10 dark:bg-[#0b57d0]/5 rounded-full blur-[120px] pointer-events-none animate-pulse delay-1000" />

        {/* Header - Refined Material 3 */}
        <header className="bg-white/70 dark:bg-[#131314]/70 backdrop-blur-xl sticky top-0 z-10 px-4 sm:px-6 py-3 sm:py-4 flex items-center justify-between border-b border-[#e1e2ec]/50 dark:border-[#444746]/50 transition-colors duration-300">
          <div className="flex items-center gap-2 sm:gap-4">
            <button
              onClick={() => setIsMobileMenuOpen(true)}
              className="lg:hidden p-2 hover:bg-[#f0f4f9] dark:hover:bg-[#333537] rounded-xl text-[#444746] dark:text-[#c4c7c5]"
            >
              <Menu size={24} />
            </button>
            <button
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="hidden lg:flex p-2 hover:bg-[#f0f4f9] dark:hover:bg-[#333537] rounded-xl text-[#444746] dark:text-[#c4c7c5]"
            >
              {isSidebarOpen ? <ChevronLeft size={24} /> : <ChevronRight size={24} />}
            </button>

            <div className="flex items-center gap-3">
              <div className="relative hidden sm:block">
                <motion.div 
                  whileHover={{ rotate: 15 }}
                  className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#0b57d0] to-[#4d8cf4] dark:from-[#a8c7fa] dark:to-[#7baaf7] flex items-center justify-center text-white dark:text-[#001d35] shadow-lg shadow-blue-200/50 dark:shadow-none"
                >
                  <Sparkles size={20} />
                </motion.div>
              </div>
              <div>
                {isEditingTitle ? (
                  <input
                    autoFocus
                    type="text"
                    value={chatTitle}
                    onChange={(e) => setChatTitle(e.target.value)}
                    onBlur={() => setIsEditingTitle(false)}
                    onKeyDown={(e) => e.key === 'Enter' && setIsEditingTitle(false)}
                    className="text-lg sm:text-xl font-bold tracking-tight text-[#041e49] dark:text-[#e3e3e3] bg-transparent border-b-2 border-[#0b57d0] dark:border-[#a8c7fa] outline-none w-full max-w-[150px] sm:max-w-[200px]"
                  />
                ) : (
                  <h1 
                    onClick={() => setIsEditingTitle(true)}
                    className="text-lg sm:text-xl font-bold tracking-tight text-[#041e49] dark:text-[#e3e3e3] cursor-pointer hover:text-[#0b57d0] dark:hover:text-[#a8c7fa] transition-colors flex items-center gap-2 group truncate max-w-[150px] sm:max-w-none"
                  >
                    {chatTitle}
                    <Sparkles size={14} className="opacity-0 group-hover:opacity-100 transition-opacity text-[#0b57d0] dark:text-[#a8c7fa] shrink-0" />
                  </h1>
                )}
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="text-[10px] font-bold uppercase tracking-widest text-[#0b57d0] dark:text-[#a8c7fa] opacity-80">Intelligence v3.1</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-2 sm:gap-3">
            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-2 text-[#444746] dark:text-[#c4c7c5] hover:bg-[#f0f4f9] dark:hover:bg-[#333537] rounded-xl transition-all"
              title={isDarkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
            >
              {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>

            <motion.button 
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={createNewSession}
              className="flex items-center gap-2 px-3 sm:px-4 py-2 bg-[#0b57d0] dark:bg-[#a8c7fa] text-white dark:text-[#001d35] rounded-xl hover:bg-[#0842a0] dark:hover:bg-[#d3e3fd] transition-all shadow-md shadow-blue-100 dark:shadow-none font-medium text-xs sm:text-sm"
            >
              <Plus size={18} />
              <span className="hidden sm:inline">New Chat</span>
            </motion.button>
            
            <button 
              onClick={clearHistory}
              className="p-2 text-[#444746] dark:text-[#c4c7c5] hover:bg-red-50 dark:hover:bg-red-900/20 hover:text-red-600 dark:hover:text-red-400 rounded-xl transition-all active:scale-95 group"
              title="Clear History"
            >
              <Trash2 size={20} />
            </button>
          </div>
        </header>

        {/* Chat Area */}
        <main 
          ref={scrollRef}
          className="flex-1 overflow-y-auto px-4 py-6 space-y-8 scroll-smooth relative z-0"
        >
          <div className="max-w-3xl mx-auto space-y-10">
            {messages.length === 0 ? (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex flex-col items-center justify-center py-20 text-center space-y-8"
              >
                <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-[#0b57d0] to-[#4d8cf4] dark:from-[#a8c7fa] dark:to-[#7baaf7] flex items-center justify-center text-white dark:text-[#001d35] shadow-2xl shadow-blue-200/50 dark:shadow-none">
                  <Sparkles size={40} />
                </div>
                <div className="space-y-3">
                  <h2 className="text-3xl font-bold tracking-tight text-[#041e49] dark:text-[#e3e3e3]">Welcome to Intelligence</h2>
                  <p className="text-[#444746] dark:text-[#c4c7c5] max-w-md mx-auto leading-relaxed">
                    Your advanced AI companion powered by Gemini. Ask me anything, from coding questions to creative writing.
                  </p>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full max-w-lg">
                  {[
                    { icon: <MessageSquare size={18} />, text: "Explain quantum physics in simple terms" },
                    { icon: <Sparkles size={18} />, text: "Write a short story about a time traveler" },
                    { icon: <Settings size={18} />, text: "Help me debug a React useEffect hook" },
                    { icon: <History size={18} />, text: "Plan a 3-day trip to Tokyo" }
                  ].map((suggestion, i) => (
                    <button
                      key={i}
                      onClick={() => setInput(suggestion.text)}
                      className="flex items-center gap-3 p-4 bg-white dark:bg-[#1e1f20] border border-[#e1e2ec] dark:border-[#444746] rounded-2xl hover:border-[#0b57d0] dark:hover:border-[#a8c7fa] hover:bg-[#f0f4f9] dark:hover:bg-[#131314] transition-all text-sm text-left group"
                    >
                      <span className="text-[#0b57d0] dark:text-[#a8c7fa] group-hover:scale-110 transition-transform">{suggestion.icon}</span>
                      <span className="text-[#444746] dark:text-[#c4c7c5]">{suggestion.text}</span>
                    </button>
                  ))}
                </div>
              </motion.div>
            ) : (
              <AnimatePresence initial={false}>
                {messages.map((msg, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, y: 20, scale: 0.98 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className={`group relative flex gap-4 max-w-[90%] sm:max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                      {/* Avatar */}
                      <div className={`w-10 h-10 rounded-2xl flex-shrink-0 flex items-center justify-center shadow-md transition-all group-hover:scale-110 group-hover:rotate-3 ${
                        msg.role === 'user' 
                          ? 'bg-[#0b57d0] dark:bg-[#a8c7fa] text-white dark:text-[#001d35]' 
                          : 'bg-white dark:bg-[#1e1f20] border border-[#e1e2ec] dark:border-[#444746] text-[#0b57d0] dark:text-[#a8c7fa]'
                      }`}>
                        {msg.role === 'user' ? <User size={20} /> : <Bot size={20} />}
                      </div>
                      
                      {/* Bubble Container */}
                      <div className={`flex flex-col gap-2 ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                        <div className={`relative rounded-[24px] px-6 py-4 shadow-sm transition-all duration-300 ${
                          msg.role === 'user' 
                            ? 'bg-[#0b57d0] dark:bg-[#a8c7fa] text-white dark:text-[#001d35] rounded-tr-none shadow-blue-100 dark:shadow-none' 
                            : 'bg-white/90 dark:bg-[#1e1f20]/90 backdrop-blur-sm text-[#1c1b1f] dark:text-[#e3e3e3] rounded-tl-none border border-[#e1e2ec] dark:border-[#444746] hover:border-[#0b57d0]/30 dark:hover:border-[#a8c7fa]/30 hover:shadow-md'
                        }`}>
                          <div className="prose prose-sm max-w-none dark:prose-invert leading-relaxed font-medium">
                            <ReactMarkdown
                              components={{
                                code({ node, inline, className, children, ...props }: any) {
                                  const match = /language-(\w+)/.exec(className || '');
                                  const codeContent = String(children).replace(/\n$/, '');
                                  
                                  if (!inline && match) {
                                    return (
                                      <div className="relative group/code">
                                        <button
                                          onClick={() => {
                                            navigator.clipboard.writeText(codeContent);
                                            // Optional: show a temporary "Copied" state for this specific block
                                          }}
                                          className="absolute right-2 top-2 p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white/50 hover:text-white opacity-0 group-hover/code:opacity-100 transition-all z-10"
                                          title="Copy code"
                                        >
                                          <Copy size={14} />
                                        </button>
                                        <code className={className} {...props}>
                                          {children}
                                        </code>
                                      </div>
                                    );
                                  }
                                  return <code className={className} {...props}>{children}</code>;
                                }
                              }}
                            >
                              {msg.text}
                            </ReactMarkdown>
                          </div>
                          
                          {/* Action Buttons (Visible on hover) */}
                          <div className={`absolute -bottom-12 flex gap-1 opacity-0 group-hover:opacity-100 transition-all duration-200 ${
                            msg.role === 'user' ? 'right-0' : 'left-0'
                          }`}>
                            <button
                              onClick={() => copyToClipboard(msg.text, idx)}
                              className="p-2 rounded-xl bg-white dark:bg-[#1e1f20] border border-[#e1e2ec] dark:border-[#444746] shadow-sm hover:bg-[#f8f9fa] dark:hover:bg-[#131314] hover:border-[#0b57d0]/30 dark:hover:border-[#a8c7fa]/30 transition-all active:scale-90"
                              title="Copy message"
                            >
                              {copiedId === idx ? (
                                <Check size={14} className="text-green-600 dark:text-green-400" />
                              ) : (
                                <Copy size={14} className="text-[#444746] dark:text-[#c4c7c5]" />
                              )}
                            </button>

                            {msg.role === 'model' && (
                              <>
                                <button
                                  onClick={() => handleFeedback(idx, 'up')}
                                  className={`p-2 rounded-xl border shadow-sm transition-all active:scale-90 ${
                                    msg.feedback === 'up' 
                                      ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800 text-green-600 dark:text-green-400' 
                                      : 'bg-white dark:bg-[#1e1f20] border-[#e1e2ec] dark:border-[#444746] text-[#444746] dark:text-[#c4c7c5] hover:bg-green-50 dark:hover:bg-green-900/20 hover:border-green-200 dark:hover:border-green-800 hover:text-green-600 dark:hover:text-green-400'
                                  }`}
                                  title="Helpful"
                                >
                                  <ThumbsUp size={14} />
                                </button>
                                <button
                                  onClick={() => handleFeedback(idx, 'down')}
                                  className={`p-2 rounded-xl border shadow-sm transition-all active:scale-90 ${
                                    msg.feedback === 'down' 
                                      ? 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800 text-red-600 dark:text-red-400' 
                                      : 'bg-white dark:bg-[#1e1f20] border-[#e1e2ec] dark:border-[#444746] text-[#444746] dark:text-[#c4c7c5] hover:bg-red-50 dark:hover:bg-red-900/20 hover:border-red-200 dark:border-red-800 hover:text-red-600 dark:hover:text-red-400'
                                  }`}
                                  title="Not helpful"
                                >
                                  <ThumbsDown size={14} />
                                </button>
                              </>
                            )}
                          </div>
                        </div>
                        
                        <span className={`text-[10px] font-bold tracking-wider text-[#444746] dark:text-[#c4c7c5] opacity-40 px-2 uppercase ${msg.role === 'user' ? 'text-right' : 'text-left'}`}>
                          {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            )}

            {isLoading && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex justify-start"
              >
                <div className="flex gap-4 items-center bg-white dark:bg-[#1e1f20] border border-[#e1e2ec] dark:border-[#444746] rounded-2xl px-5 py-3 shadow-sm border-l-4 border-l-[#0b57d0] dark:border-l-[#a8c7fa]">
                  <div className="flex gap-1">
                    {[0, 1, 2].map((dot) => (
                      <motion.div
                        key={dot}
                        animate={{ y: [0, -6, 0] }}
                        transition={{
                          duration: 0.6,
                          repeat: Infinity,
                          delay: dot * 0.15,
                          ease: "easeInOut"
                        }}
                        className="w-1.5 h-1.5 bg-[#0b57d0] dark:bg-[#a8c7fa] rounded-full"
                      />
                    ))}
                  </div>
                  <span className="text-sm font-medium text-[#444746] dark:text-[#c4c7c5]">Gemini is thinking...</span>
                </div>
              </motion.div>
            )}

            {error && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex justify-center p-4"
              >
                <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-400 px-6 py-4 rounded-2xl flex flex-col items-center gap-3 text-sm font-medium shadow-sm max-w-md text-center">
                  <div className="flex items-center gap-2">
                    <AlertCircle size={20} />
                    <span>{error}</span>
                  </div>
                  <button 
                    onClick={() => {
                      setError(null);
                      handleSend();
                    }}
                    className="mt-2 px-4 py-2 bg-red-600 dark:bg-red-500 text-white dark:text-white rounded-xl hover:bg-red-700 dark:hover:bg-red-600 transition-all active:scale-95 text-xs font-bold uppercase tracking-wider"
                  >
                    Try Again
                  </button>
                </div>
              </motion.div>
            )}
            <div ref={messagesEndRef} className="h-4" />
          </div>
        </main>

        {/* Input Area */}
        <footer className="bg-white/70 dark:bg-[#131314]/70 backdrop-blur-xl p-3 sm:p-4 border-t border-[#e1e2ec]/50 dark:border-[#444746]/50 relative z-10 transition-colors duration-300">
          <div className="max-w-3xl mx-auto">
            <div className="relative flex items-center bg-white dark:bg-[#1e1f20] border border-[#e1e2ec] dark:border-[#444746] rounded-[28px] sm:rounded-[32px] px-4 py-1.5 transition-all focus-within:ring-2 focus-within:ring-[#0b57d0]/20 dark:focus-within:ring-[#a8c7fa]/20 focus-within:border-[#0b57d0] dark:focus-within:border-[#a8c7fa] focus-within:shadow-lg shadow-sm">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSend();
                  }
                }}
                placeholder="Message Gemini..."
                aria-label="Message Gemini"
                rows={1}
                className="flex-1 bg-transparent border-none py-2.5 sm:py-3 focus:ring-0 resize-none min-h-[44px] max-h-60 text-sm sm:text-[15px] outline-none font-medium text-[#1c1b1f] dark:text-[#e3e3e3]"
                onInput={(e) => {
                  const target = e.target as HTMLTextAreaElement;
                  target.style.height = 'auto';
                  target.style.height = `${target.scrollHeight}px`;
                }}
              />
              
              <div className="flex items-center gap-3 shrink-0 ml-2">
                {/* Character Counter Circle - More subtle */}
                <div 
                  className="relative w-6 h-6 flex items-center justify-center cursor-help opacity-60 hover:opacity-100 transition-opacity"
                  title={`${input.length} / ${MAX_CHARS} characters`}
                >
                  <svg className="w-full h-full transform -rotate-90">
                    <circle
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      fill="transparent"
                      className="text-[#e1e2ec] dark:text-[#444746]"
                    />
                    <motion.circle
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      fill="transparent"
                      strokeDasharray={63}
                      animate={{ strokeDashoffset: 63 - (63 * Math.min(input.length, MAX_CHARS)) / MAX_CHARS }}
                      className={`${
                        input.length > MAX_CHARS 
                          ? 'text-red-500' 
                          : input.length > MAX_CHARS * 0.9 
                            ? 'text-orange-500' 
                            : 'text-[#0b57d0] dark:text-[#a8c7fa]'
                      }`}
                    />
                  </svg>
                  {input.length > MAX_CHARS * 0.8 && (
                    <span className={`absolute text-[8px] font-bold ${input.length > MAX_CHARS ? 'text-red-500' : 'text-[#444746] dark:text-[#c4c7c5]'}`}>
                      {MAX_CHARS - input.length}
                    </span>
                  )}
                </div>

                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={handleSend}
                  disabled={!input.trim() || isLoading || input.length > MAX_CHARS}
                  aria-label="Send message"
                  className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center transition-all ${
                    !input.trim() || isLoading || input.length > MAX_CHARS
                      ? 'bg-[#f0f4f9] dark:bg-[#131314] text-[#c4c7c5] dark:text-[#444746] cursor-not-allowed' 
                      : 'bg-[#0b57d0] dark:bg-[#a8c7fa] text-white dark:text-[#001d35] shadow-md shadow-blue-200 dark:shadow-none'
                  }`}
                >
                  <Send size={18} />
                </motion.button>
              </div>
            </div>
            <div className="flex justify-center mt-2">
              <p className="text-[9px] font-bold uppercase tracking-widest text-[#444746] dark:text-[#c4c7c5] opacity-30">
                Gemini 3 Flash • Advanced Reasoning
              </p>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
```
